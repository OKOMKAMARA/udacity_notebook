import argparse

import torch
from torch.autograd import Variable
from torchvision import datasets, transforms, models
import torchvision.datasets as datasets
import torch.nn.functional as F
import torchvision
import torchvision.models as models
from collections import OrderedDict
#import matplotlib.pyplot as plt
import numpy as np
from PIL import Image
import json


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('checkpoint', action='store', default='checkpoint.pth')
    parser.add_argument('--top_k', dest='top_k', default='5')
    parser.add_argument('--pathname', dest='pathname', default='flowers/test/1/image_06743.jpg')
    parser.add_argument('--category_names', dest='category_names', default='cat_to_name.json')
    parser.add_argument('--gpu', action='store', default='gpu')
    return parser.parse_args()




# Save the checkpoint

# model.class_to_idx = image_datasets[0].class_to_idx
test_transforms = transforms.Compose([transforms.Resize(256),
                                              transforms.CenterCrop(224),
                                              transforms.ToTensor(),
                                              transforms.Normalize([0.485, 0.456, 0.406],
                                                                   [0.229, 0.224, 0.225])])
   
def load_checkpoint(pathname):
  checkpoint = torch.load(pathname)
  arch = checkpoint['arch']
  model = getattr(torchvision.models, checkpoint['arch'])(pretrained = True)
  model.classifier = checkpoint['classifier']
  learning_rate = checkpoint['learning_rate']
  model.epochs = checkpoint['epochs']
  model.optimizer = checkpoint['optimizer']
  model.class_to_idx = checkpoint['class_to_idx']
  model.load_state_dict(checkpoint['state_dic'])


  return model


# Load the model
model = load_checkpoint('checkpoint.pth')
print(model)

def process_image(image):
    ''' Scales, crops, and normalizes a PIL image for a PyTorch model,
        returns an Numpy array
    '''
     # TODO: Process a PIL image for use in a PyTorch model
    image = Image.open(image)

    # prepare image tensor
    image_tensor = test_transforms(image)

    return image_tensor
'''
def imshow(image, ax = None, title = None):
  """Imshow for Tensor."""
  if ax is None:
    fig, ax = plt.subplots()

  # PyTorch tensors assume the color channel is the first dimension
  # but matplotlib assumes is the third dimension
  image = image.transpose(1, 2, 0)

  # Undo preprocessing

  mean = np.array([0.485, 0.456, 0.406])
  std = np.array([0.229, 0.224, 0.225])
  image = std * image + mean

  # Image needs to clipped between o and 1 or its looks like noise when displayed
  image = np.clip(image, 0, 1)

  ax.imshow(image)

  return ax
'''

#Display the original and modified image
image_pth = 'flowers/test/1/image_06743.jpg'

# original
'''
with Image.open(image_pth) as image:
  plt.imshow(image)
'''

#from torch.autograd import Variable
def predict(image_path, model, topk=5):
    ''' Predict the class (or classes) of an image using a trained deep learning model.
    '''

    # TODO: Implement the code to predict the class from an image file
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    model.eval()
    model = model.to(device)

    # Process image
    image = process_image(image_path)
    image = process_image(image_path)
    image = image.unsqueeze(0)

    image = image.to(device)
    # Transfer to tensor
    #image = torch.from_numpy(np.array([image])).float()

    #image = image.to(device)

    output = model.forward(image)

    # Top probs
    probabilities = torch.exp(output).data

    top_probs, top_labs = probabilities.topk(topk)

    top_probs = top_probs.cpu().detach().numpy().tolist()[0]
    top_labs = top_labs.cpu().detach().numpy().tolist()[0]

    # Convert indices to classes
    idx_to_class = {val: key for key, val in model.class_to_idx.items()}
    top_labels = [idx_to_class[lab] for lab in top_labs]
        # Displays the category name
    index_to_class = {val:k for k, val in model.class_to_idx.items()}

    classes = [index_to_class[i] for i in top_labs]

    return top_probs,top_labels

# Implement the predict function on an image
image_path = 'flowers/test/1/image_06743.jpg' # should be pink primrose

probs, labs = predict(image_path, model)

print(probs)
print(labs)


probs, labs = predict(image_path, model)
max_index = np.argmax(probs)
max_probability = probs[max_index]
# label = classes[max_index]

#fig = plt.figure(figsize=(6,6))
#ax1 = plt.subplot2grid((15,9), (0,0), colspan=9, rowspan=9)
#ax2 = plt.subplot2grid((15,9), (9,2), colspan=5, rowspan=5)

#image = Image.open(image_path)
#ax1.axis('off')
#ax1.set_title(label)
#ax1.imshow(image)

#y_pos = np.arange(5)
#ax2.set_yticks(y_pos)
#ax2.set_yticklabels(classes)
#ax2.set_xlabel('Probability')
#ax2.invert_yaxis()
#ax2.barh(y_pos, probs, xerr=0, align='center', color='blue')

#plt.show()


