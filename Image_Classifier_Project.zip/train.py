import argparse

import torch
from torch import nn
from torch import optim
from torch.autograd import Variable
from torchvision import datasets, transforms, models
from torchvision.datasets import ImageFolder
import torch.nn.functional as F

from PIL import Image

from collections import OrderedDict
import json
import time

import numpy as np
import matplotlib.pyplot as plt


# from utils import save_checkpoint, load_checkpoint

# Define the command line arguments

def parse_args():
    parser = argparse.ArgumentParser(description='Training')
    parser.add_argument('--data_dir', action='store')
    parser.add_argument('--arch', dest='arch', default='vgg16', choices=['vgg16', 'densenet121'])  
    parser.add_argument('--learning_rate', dest='learning_rate', default='0.001')
    parser.add_argument('--hidden_units', dest='hidden_units', default='512')
    parser.add_argument('--epochs', dest='epochs', default='1')
    parser.add_argument('--gpu', action='store', default='gpu')
    parser.add_argument('--save_dir', dest='save_dir', action='store', default='checkpoint.pth')
    
    return  parser.parse_args()


    
def main():
    args = parse_args()
                  
    data_dir = 'flowers'
    train_dir = data_dir + '/train'
    valid_dir = data_dir + '/valid'
    test_dir = data_dir + '/test'
                  
#          Define your transforms for the training, validation, and testing sets
    train_transforms = transforms.Compose([transforms.RandomRotation(30),
                                               transforms.RandomResizedCrop(224),
                                               transforms.RandomHorizontalFlip(),
                                               transforms.ToTensor(),
                                               transforms.Normalize([0.485, 0.456, 0.406],
                                                                    [0.229, 0.224, 0.225])])
    validation_transforms = transforms.Compose([transforms.Resize(256),
                                                   transforms.CenterCrop(224),
                                                   transforms.ToTensor(),
                                                   transforms.Normalize([0.485, 0.456, 0.406],
                                                                        [0.229, 0.224, 0.225])])
    test_transforms = transforms.Compose([transforms.Resize(256),
                                              transforms.CenterCrop(224),
                                              transforms.ToTensor(),
                                              transforms.Normalize([0.485, 0.456, 0.406],
                                                                   [0.229, 0.224, 0.225])])
#       Load the datasets with ImageFolder
    image_datasets = [datasets.ImageFolder(train_dir, transform = train_transforms),
                          datasets.ImageFolder(valid_dir, transform = validation_transforms),
                          datasets.ImageFolder(test_dir, transform = test_transforms)]
                  
#       Using the image datasets and the transforms, define the dataloaders
    dataloaders = [torch.utils.data.DataLoader(image_datasets[0], batch_size = 64, shuffle = True),
                       torch.utils.data.DataLoader(image_datasets[1], batch_size = 64),
                       torch.utils.data.DataLoader(image_datasets[2], batch_size = 64)]
                  
#     model = getattr(models, args.arch)(pretrained = True)
    with open('cat_to_name.json', 'r') as f:
        cat_to_name = json.load(f)
    
#     Build and train your network
    device = torch.device('cuda' if torch.cuda.is_available() else 'cup')
    model = models.vgg16(pretrained = True)
    model 
#       Freeze parameters so we don't backprop through them          
    for param in model.parameters():
        param.requires_grad = False
                  
    
        classifier = nn.Sequential(OrderedDict([
                                  ('fc1', nn.Linear(25088, 4096)),
                                  ('relu', nn.ReLU()),
                                  ('dropout', nn.Dropout(0.2)),
                                  ('fc2', nn.Linear(4096, 512)),
                                  ('relu', nn.ReLU()),
                                  ('fc3', nn.Linear(512, 102)),
                                  ('output', nn.LogSoftmax(dim=1))]))
#     elif args.arch == "densenet121":
#         classifier = nn.Sequential(OrderedDict([
#                                   ('fc1', nn.Linear(1024, 500)),
#                                   ('dropout', nn.Dropout(p=0.6)),
#                                   ('relu', nn.ReLU()),
#                                   ('fc2', nn.Linear(500, 102)),
#                                   ('output', nn.LogSoftmax(dim=1))]))

#         Update the classifier in the model
#     
    model.classifier = classifier 
    model
#     Move the model to cuda
    model = model.to(device)
#     Define the learning rate
    learning_rate = 0.001
#         Define the loss
    criterion = nn.NLLLoss()
#        Only train the classifier parameters, feature parametersare frozon
    optimizer = optim.Adam(model.classifier.parameters(), lr = learning_rate)  
#     epochs = int(args.epochs)
#     class_index = image_datasets[0].class_to_idx
#         # Get the gpu settings
#     gpu = args.gpu 
#     train(model, criterion, optimizer, dataloaders, epochs, gpu)
#     model.class_to_idx = class_index
#       # New save location
#     path = args.save_dir  
#     save_checkpoint(path, model, optimizer, args, classifier)
                                      
#def train(model, criterion, optimizer, dataloaders, epochs, gpu):
    epochs = 1
    print_every = 10
    steps = 0
    start = time.time()
    print('Starting training')
    for e in range(epochs):
        running_loss = 0
        for ii, (inputs, labels) in enumerate(dataloaders[0]):
            steps += 1
            # Move input and label tensors to the defaults device (use cuda)
            inputs, labels = inputs.to(device), labels.to(device)
            # Zeros the gradients on each training pass
            optimizer.zero_grad()
            # Forward and backward passes
            outputs = model.forward(inputs)
            # Use the logits to calculate the loss
            loss = criterion(outputs, labels)
            # Perform a backward pass through the network to calculate the gradients
            loss.backward()
            # Take a step with the optimizer to update the weights
            optimizer.step()
            # Calculate the training loss
            running_loss += loss.item()
        else:
            model.eval()
            valloss = 0
            accuracy = 0
            for ii, (inputs2, labels2) in enumerate(dataloaders[1]):
                optimizer.zero_grad()
                inputs2, labels2 = inputs2.to(device), labels2.to(device)
                logps = model(inputs2)
                valloss += criterion(logps, labels2)
                ps = torch.exp(logps).data
                top_ps, top_class = ps.topk(1, dim=1)
                equality = top_class == labels2.view(*top_class.shape)
                accuracy += torch.mean(equality.type(torch.FloatTensor))
            print("Epoch: {}/{}".format(e + 1, epochs))
            print("Training loss: {:4f}, Validation loss: {:4f}, Accuracy: {:4f}".format(
                running_loss / len(dataloaders[0]),
                valloss / len(dataloaders[1]),
                accuracy / len(dataloaders[1])
            ))
            running_loss = 0
    time_elapsed = time.time() - start
    print("\nTime spent training: {:.0f}m {:.0f}s".format(time_elapsed // 60, time_elapsed % 60))
                  
    model.class_to_idx = image_datasets[0].class_to_idx
    
    checkpoint = {'input_size': 25088,
              'output_size': 102,
              'arch': 'vgg16',
              'classifier': classifier,
              'learning_rate': 0.001,
              'batch_size': 64,
              'epochs': epochs,
              'class_to_idx': model.class_to_idx,
              'state_dic': model.state_dict(),
              'optimizer': optimizer.state_dict()
          }

# Save it to a file

    torch.save(checkpoint, 'checkpoint.pth')
if __name__ == "__main__":
    main()